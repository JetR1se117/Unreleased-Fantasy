﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireBlast : MonoBehaviour
{
    public GameObject Target;

    private void Start()
    {

    }

    void Update()
    {
        if (Target != null)
        {
            Vector3 targetPostition = new Vector3(Target.transform.position.x, Target.transform.position.y, Target.transform.position.z);
            
            this.transform.LookAt(targetPostition);

            float distance2 = Vector3.Distance(Target.transform.position, this.transform.position);

            if (distance2 > 2.0f)
            {
                transform.Translate(Vector3.forward * 30.0f * Time.deltaTime);
            }
            else
            {
                HitTarget();
            }
        }
    }
    void HitTarget()
    {
        //Send Message
        Destroy(this.gameObject);
    }
}
