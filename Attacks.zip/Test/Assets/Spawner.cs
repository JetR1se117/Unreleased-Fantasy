﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject projectile;
    public float projectileSpeed;

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            GameObject fireblast = Instantiate(projectile, transform) as GameObject;
            Rigidbody rb = fireblast.GetComponent<Rigidbody>();
            rb.velocity = transform.forward * projectileSpeed;
        }
    }


}
